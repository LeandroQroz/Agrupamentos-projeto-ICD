# Análise-sobre-acidentes-de-transito
Repositório para o projeto de INTRODUÇÃO À CIÊNCIA DE DADOS

Alunos: Jafet de Lima, Leandro Queiroz e Mateus Pereira

Os dados serão retirados do https://www.kaggle.com/datasets/mcamera/brazil-highway-traffic-accidents

Descreva as princiapais causas de acidentes e suas consequencias.

Exemplifique os dados em mapas.

Usando agrupamentos defina as regiões do Brasil.
